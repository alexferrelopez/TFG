<template>
  <router-view />
</template>

<script setup>
// Empty on purpose
</script>
